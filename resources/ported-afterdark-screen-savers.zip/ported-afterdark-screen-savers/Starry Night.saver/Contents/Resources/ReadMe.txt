Screensaver notes
=================

Starry Night screensaver

Copyright (c) 2012 Dan Yu. Portions Copyright (c) 2010 Evan Green

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

A from-scratch (thanks to Evan Green) recreation of a Berkeley Systems After Dark classic
module.  If you enable "Retro Colors" (e.g. grayscale) and squint a bit, you can
pretend your Mac has traveled back in time and become a Mac Classic.

Uses Cocoa drawing calls that should work on any Mac running Mac OS 10.5 or later.

Note that in preview mode, the screensaver doesn't currently take into account the
smaller view and draws the same number of buildings that would be drawn in the full
screen mode, so this may not be an accurate preview of the generated building layout.

Credit for the original Starry Night belongs to Berkeley Systems.